import pygame
from weblazy import LazyImages, lazy_path  # web: load when shown

### Function to load images based on the spots and orientations
# !!! ADJUST
def load_images_mov(num_spots, num_orientations):
    images = LazyImages()
    for spot in range(1, num_spots + 1):
        for orientation in range(1, num_orientations + 1):
            key = f"{spot}_{orientation}"
            try:
                images[key] = lazy_path(f'files/background/mission3/{key}.jpg')
            except FileNotFoundError:
                print(f"Error: image file 'files/background/mission3/{key}.jpg' not found.")
                images[key] = None  # Assign None or a placeholder image

    return images