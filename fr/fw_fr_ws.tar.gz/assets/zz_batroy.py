# The game now starts from main.py (needed for the web version).
# This file is kept so 'python zz_batroy.py' still works.
import runpy
runpy.run_path('main.py', run_name='__main__')
