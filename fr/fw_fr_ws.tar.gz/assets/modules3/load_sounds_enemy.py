import os
import pygame
from modules3.soundfix import load_sound

def load_sounds_enemy(sound_folder):
    # List of sound files for each set
    sound_files1 = ["11.ogg", "12.ogg", "13.ogg", "14.ogg"]
    sound_files2 = ["21.ogg", "22.ogg", "23.ogg", "24.ogg"]
    sound_files3 = ["31.ogg", "32.ogg", "33.ogg", "34.ogg"]
    sound_files4 = ["41.ogg", "42.ogg", "43.ogg", "44.ogg"]
    sound_files5 = ["51.ogg", "52.ogg", "53.ogg", "54.ogg"]
    sound_files6 = ["61.ogg", "62.ogg", "63.ogg", "64.ogg"]
    # Kakachi (enemy 7). The files 71-74.ogg are now Everest's (the dog of the Ultimate Mission),
    # so level 3 uses the original Kakachi copies 71kakachi-74kakachi.ogg (keys stay '71'-'74').
    sound_files7 = ["71kakachi.ogg", "72kakachi.ogg", "73kakachi.ogg", "74kakachi.ogg"]


    # Function to load sounds into a dictionary
    def load_sounds(sound_files):
        sound_dict = {}
        for sound_file in sound_files:
            sound_path = os.path.join(sound_folder, sound_file)  # Construct full file path
            sound_name = os.path.splitext(sound_file)[0].replace('kakachi', '')  # File name without extension (e.g. '71')
            sound = load_sound(sound_path)
            sound_dict[sound_name] = sound
        return sound_dict

    # Load sounds for each set
    sound_dict1 = load_sounds(sound_files1)
    sound_dict2 = load_sounds(sound_files2)
    sound_dict3 = load_sounds(sound_files3)
    sound_dict4 = load_sounds(sound_files4)
    sound_dict5 = load_sounds(sound_files5)
    sound_dict6 = load_sounds(sound_files6)
    sound_dict7 = load_sounds(sound_files7)

    
    return sound_dict1, sound_dict2, sound_dict3, sound_dict4, sound_dict5, sound_dict6, sound_dict7


'''
def load_sounds_enemy(sound_folder, sound_keys):
    """
    Load sounds from a specified folder and store them in a dictionary.

    Args:
    sound_folder (str): Path to the folder containing sounds.
    sound_keys (list): List of sound file keys to load (without extension).

    Returns:
    dict: Dictionary containing three sub-dictionaries with sound keys and loaded sounds.
    """
    # Initialize the sub-dictionaries
    sub_sound_dict1 = {}
    sub_sound_dict2 = {}
    sub_sound_dict3 = {}
    
    # Load the sounds into the appropriate sub-dictionaries
    for key in sound_keys:
        filename = f"{key}.ogg"
        sound_path = os.path.join(sound_folder, filename)
        sound = load_sound(sound_path)
        
        if key.startswith('1'):
            sub_sound_dict1[key] = sound
        elif key.startswith('2'):
            sub_sound_dict2[key] = sound
        elif key.startswith('3'):
            sub_sound_dict3[key] = sound

    # Combine the sub-dictionaries into the main sound_dict
    sound_dict = {
        'sub_sound_dict1': sub_sound_dict1,
        'sub_sound_dict2': sub_sound_dict2,
        'sub_sound_dict3': sub_sound_dict3
    }

    return sound_dict
    '''