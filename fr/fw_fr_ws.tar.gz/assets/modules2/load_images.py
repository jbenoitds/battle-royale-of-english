import pygame
from weblazy import LazyImages, lazy_path  # web: load when shown

### Function to load images based on the spots and orientations
#
def load_images(num_spots, num_orientations):
    images = LazyImages()
    for spot in range(1, num_spots + 1):
        for orientation in range(1, num_orientations + 1):
            key = f"{spot}_{orientation}"
            try:
                images[key] = lazy_path(f'files/background/mission2/{key}.jpg')
            except FileNotFoundError:
                print(f"Erreur: Fichier image 'files/background/mission2/{key}.jpg' non trouvé.")
                images[key] = None  # Assign None or a placeholder image
    return images 